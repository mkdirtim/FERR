# Pentest Findings – OWASP Juice Shop

**Target (in-scope):** http://juiceshop:3000  
**Date:** 2026-02-13  
**Tester:** Automated assessment (low-noise, unauthenticated)

---

## Finding 1: Publicly accessible `/ftp/` directory (sensitive file exposure)
**Severity:** High

### Description
`/robots.txt` discloses and the server allows unauthenticated browsing of the `/ftp/` directory. The directory listing exposes multiple potentially sensitive files (e.g., backups, encrypted content, password database). Even if some content is “encrypted”, the mere exposure increases attack surface (offline cracking, information disclosure, supply-chain intel).

### Affected asset / endpoint(s)
- `GET http://juiceshop:3000/robots.txt`
- `GET http://juiceshop:3000/ftp/`

### Evidence (observed)
- `robots.txt` contains:
  - `Disallow: /ftp`
- `/ftp/` returns `200 OK` and displays a directory index with links including:
  - `coupons_2013.md.bak`
  - `package-lock.json.bak`
  - `incident-support.kdbx`
  - `encrypt.pyc`

### Steps to reproduce
1. `curl -sS http://juiceshop:3000/robots.txt`
2. `curl -sS http://juiceshop:3000/ftp/`
3. Review the directory listing and download exposed files.

### Impact
Attackers can download internal/backup artifacts and secrets, enabling credential recovery, further exploitation, and business data leakage.

### Recommended remediation
- Disable directory listing on `/ftp/`.
- Restrict access (authz) to intended users only, or remove the endpoint from production.
- Remove backup/secret files from web root (e.g., `*.bak`, `*.kdbx`, build artifacts).

**References:** OWASP ASVS V14, CWE-548 (Exposure of Information Through Directory Listing)

---

## Finding 2: Permissive CORS policy (`Access-Control-Allow-Origin: *`)
**Severity:** Medium

### Description
The application responds with `Access-Control-Allow-Origin: *` on the main page. If any authenticated endpoints also return `*` (or reflect arbitrary origins) and the app uses bearer tokens or allows credentialed cross-origin reads, this can enable cross-site data access by malicious origins.

### Affected asset / endpoint(s)
- `GET http://juiceshop:3000/`

### Evidence (observed)
- Response header:
  - `Access-Control-Allow-Origin: *`

### Steps to reproduce
1. `curl -sS -D- http://juiceshop:3000/ -o /dev/null | grep -i access-control-allow-origin`

### Impact
Increases risk of cross-origin data exfiltration depending on how APIs handle authentication and CORS across sensitive endpoints.

### Recommended remediation
- Set `Access-Control-Allow-Origin` to explicit trusted origins.
- Ensure sensitive endpoints never allow wildcard origins for authenticated responses.

**References:** OWASP CORS guidance, CWE-942 (Permissive Cross-domain Policy)

---

## Finding 3: Missing key security headers (CSP / HSTS)
**Severity:** Low

### Description
The main page response lacks common security headers that reduce exploitability of client-side attacks and downgrade risks.

### Affected asset / endpoint(s)
- `GET http://juiceshop:3000/`

### Evidence (observed)
Missing:
- `Content-Security-Policy`
- `Strict-Transport-Security` (note: app currently served over HTTP)

### Steps to reproduce
1. `curl -sS -D- http://juiceshop:3000/ -o /dev/null`

### Impact
Reduced browser-side protections; increases likelihood/impact of XSS and transport downgrade/SSL-strip (if deployed with TLS elsewhere).

### Recommended remediation
- Deploy TLS and enable HSTS (when HTTPS is in use).
- Add a CSP aligned with the application’s script/style needs.

**References:** OWASP Secure Headers Project

---

## Notes / Next test steps (not executed)
- Enumerate `/api/*` endpoints, auth flows, and verify whether CORS wildcard applies to authenticated API responses.
- Review `/ftp/` files for embedded secrets/keys and validate whether downloads are intended.
