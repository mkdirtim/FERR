# Juice Shop Pentest Findings (http://juiceshop:3000)

Date: 2026-02-13  
Scope: `http://juiceshop:3000` only  
Approach: low-noise unauthenticated recon + passive JS/API surface mapping.

## Executive summary
The application exposes multiple unauthenticated API endpoints and is configured with permissive CORS (`Access-Control-Allow-Origin: *`). This materially increases the blast radius of any future auth/session weakness and enables cross-origin reads from any website for endpoints that do not require authentication.

## Finding 1: Permissive CORS policy (`*`) on application responses
**Severity:** Medium (context-dependent; can be High when combined with auth/session or sensitive unauth endpoints)

### Description
Responses from the main application and API endpoints include:
- `Access-Control-Allow-Origin: *`

This allows any origin to read responses via browsers. While browsers will not send credentialed cookies on cross-origin XHR/fetch unless `Access-Control-Allow-Credentials: true`, this is still risky when:
- endpoints are unauthenticated and return sensitive data (e.g., product metadata, user enumeration, hints/challenges), or
- the app uses bearer tokens in localStorage and frontends can be induced to run attacker JS, or
- future endpoints are added that incorrectly rely on CORS for access control.

### Affected assets / endpoints (observed)
- `GET /` (homepage)
- `GET /robots.txt`
- `GET /api/Products`

### Steps to reproduce
1. Request the homepage:
   ```bash
   curl -i http://juiceshop:3000/
   ```
2. Observe header:
   - `Access-Control-Allow-Origin: *`

### Impact
Cross-origin web pages can read responses from this application for any endpoint that is accessible without credentials, increasing data exposure and enabling easier chaining with XSS/token theft or mis-scoped APIs.

### Recommended remediation
- Restrict `Access-Control-Allow-Origin` to trusted origins (specific scheme+host), per environment.
- Do not rely on CORS as an authorization mechanism.
- Ensure sensitive endpoints require authentication/authorization regardless of CORS.

**References:** OWASP CORS Misconfiguration; CWE-942

---

## Finding 2: Unauthenticated API data exposure (public API surface)
**Severity:** Low → Medium (depends on sensitivity of returned fields)

### Description
At least one API endpoint is reachable and returns JSON without authentication:
- `GET /api/Products` → `200 OK` with `Content-Type: application/json`

Additionally, JS surface mapping indicates many other API routes likely exist (not all were probed to keep noise low), including:
- `/api/Users`, `/api/Feedbacks`, `/api/Complaints`, `/api/Cards`, `/api/Addresss`, `/api/BasketItems`, `/api/Deliverys`, `/api/SecurityQuestions`, `/api/SecurityAnswers`, `/api/Hints`, `/api/Challenges`, etc.

### Evidence
- `GET http://juiceshop:3000/api/Products` returned `200 OK` and a JSON body.

### Steps to reproduce
1. Query products endpoint:
   ```bash
   curl -i http://juiceshop:3000/api/Products
   ```
2. Confirm it responds `200 OK` with JSON.

### Impact
Publicly accessible APIs increase attack surface for:
- information disclosure (fields, internal IDs),
- enumeration of objects (IDs used later for IDOR),
- business logic probing without authentication.

### Recommended remediation
- Review intended public endpoints and explicitly require auth for non-public resources.
- Apply response field minimization (avoid internal IDs/secrets/PII).
- Add rate limiting and monitoring on enumeration-prone endpoints.

**References:** OWASP API Security Top 10 (API1, API3)

---

## Finding 3: Information disclosure via `X-Recruiting` header
**Severity:** Informational

### Description
Responses include a custom header:
- `X-Recruiting: /#/jobs`

This discloses an internal route and provides an additional discovery signal to attackers.

### Steps to reproduce
```bash
curl -i http://juiceshop:3000/ | grep -i x-recruiting
```

### Impact
Minor increase in discoverability of hidden functionality/paths.

### Recommended remediation
Remove non-essential informational headers in production.

---

## Observed attack surface (from JS mapping)
Front-end JS references the following high-value paths:
- Auth/UI flows: `/login`, `/checkout`, `/payment`, `/order-summary`, `/order-history`, `/orders`, `/order-completion`
- APIs: `/api/Products`, `/api/Users`, `/api/Feedbacks`, `/api/Complaints`, `/api/BasketItems`, `/api/Addresss`, `/api/Cards`, `/api/Deliverys`, `/api/SecurityQuestions`, `/api/SecurityAnswers`, `/api/Hints`, `/api/Challenges`, `/api/Recycles`, `/api/Quantitys`

## Next steps (focused, low-noise)
- Validate which `/api/*` endpoints are accessible unauthenticated and identify any PII/secrets exposure.
- Exercise auth flow and test for:
  - user enumeration, weak password reset, JWT/cookie flags, session fixation,
  - IDOR across baskets/addresses/orders,
  - stored/reflected XSS in feedback/complaints.
