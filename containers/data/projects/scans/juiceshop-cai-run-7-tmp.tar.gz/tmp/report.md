# OWASP Juice Shop (http://juiceshop:3000) – Pentest Findings (Snapshot)

Scope: `http://juiceshop:3000` only.

## High-level recon
- App appears to be an Angular SPA serving JS bundles: `/runtime.js`, `/polyfills.js`, `/vendor.js`, `/main.js`.
- JS-derived endpoints observed (non-exhaustive):
  - `/api/Products`, `/api/Users`, `/api/BasketItems`, `/api/Addresss`, `/api/Cards`, `/api/Deliverys`, `/api/Complaints`, `/api/Feedbacks`, `/api/Quantitys`, `/api/Recycles`, `/api/SecurityQuestions`, `/api/SecurityAnswers`, `/api/Challenges`, `/api/Hints`
  - App routes: `/#/login`, `/#/checkout`, `/#/orders`, `/#/order-history`, `/#/payment`, `/#/accounting`

## Findings

### 1) Permissive CORS on main origin
**Severity:** Medium (context-dependent)

**Description:**
The root document responds with `Access-Control-Allow-Origin: *`, allowing any website to read responses from this origin via XHR/fetch *when responses are not protected by credentials*, and enabling broad cross-origin interaction patterns. If any sensitive endpoints are accessible without credentials or if tokens are stored in browser-accessible locations and used in cross-origin contexts, this can amplify data exposure risks.

**Affected:**
- `GET http://juiceshop:3000/` (observed header)

**Steps to reproduce:**
1. `curl -i http://juiceshop:3000/ | grep -i access-control-allow-origin`
2. Observe: `Access-Control-Allow-Origin: *`

**Impact:**
Potential cross-origin data exfiltration of any non-authenticated sensitive resources; increased attack surface for cross-site abuse patterns.

**Recommendation:**
- Set CORS to a strict allowlist of trusted origins (or disable if not required).
- Ensure sensitive endpoints require authentication and do not rely on CORS as an access control.

**References:** OWASP CORS misconfiguration

---

### 2) Missing Content Security Policy (CSP)
**Severity:** Medium

**Description:**
No `Content-Security-Policy` header observed on the root document. CSP significantly reduces impact of XSS by restricting script sources and other dangerous sinks.

**Affected:**
- `GET http://juiceshop:3000/`

**Steps to reproduce:**
1. `curl -i http://juiceshop:3000/ | grep -i content-security-policy`
2. No output (header absent)

**Impact:**
If an XSS is found elsewhere, lack of CSP can allow easier script execution, data theft, and session compromise.

**Recommendation:**
- Deploy a restrictive CSP (e.g., `default-src 'self'; script-src 'self' ...`) and iterate using report-only mode first.

**References:** OWASP XSS Prevention Cheat Sheet (CSP)

---

### 3) No transport security enforcement (HSTS not present; HTTP in use)
**Severity:** Medium

**Description:**
The application is served over HTTP and no `Strict-Transport-Security` header is present. HSTS is only meaningful over HTTPS, but its absence plus HTTP usage increases risk of credential/session interception on untrusted networks.

**Affected:**
- `GET http://juiceshop:3000/`

**Steps to reproduce:**
1. `curl -i http://juiceshop:3000/ | grep -i strict-transport-security`
2. No output (header absent)

**Impact:**
Susceptible to MITM on networks where attacker can intercept traffic; downgrade/sslstrip-style risks if HTTPS exists but isn’t enforced.

**Recommendation:**
- Serve the application over HTTPS.
- Add HSTS once HTTPS is deployed: `Strict-Transport-Security: max-age=31536000; includeSubDomains` (and consider preload).

**References:** OWASP Transport Layer Protection

---

## Notes / next steps (not executed)
- Validate authn/authz posture on discovered API endpoints (IDOR/role checks), especially `/api/Users`, `/api/Cards`, `/api/Addresss`, `/api/BasketItems`, `/api/Complaints`.
- Check for common Juice Shop issues (SQLi/login bypass, stored XSS in feedback/complaints, SSRF via any URL fetcher) in a safe, non-destructive manner.
