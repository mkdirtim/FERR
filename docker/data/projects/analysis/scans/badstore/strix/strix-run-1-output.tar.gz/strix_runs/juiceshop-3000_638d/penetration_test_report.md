# Security Penetration Test Report

**Generated:** 2026-02-13 00:41:56 UTC

# Executive Summary

An external penetration test of the web application at http://juiceshop:3000 identified multiple critical security vulnerabilities that enable complete application compromise. Confirmed issues include unauthenticated SQL injection leading to database exfiltration, authentication bypass to obtain administrative JWTs, privilege escalation to administrative role via mass assignment, and a DOM-based XSS that can steal user tokens. Additionally, broken object-level authorization enables cross-user data access and unauthorized modifications across business objects, and exposed file/configuration endpoints leak sensitive operational artifacts and internal stack traces.

Overall risk posture: Critical.

Business impact
An external attacker can gain administrative access without valid credentials, extract or tamper with user and transactional data, and hijack user sessions via token theft. The exposed file server content (including a KeePass database) also introduces a high risk of credential compromise and lateral movement if secrets are present.

# Methodology

Testing was performed as a black-box external web application assessment aligned with OWASP WSTG principles.

Scope
- In-scope target: http://juiceshop:3000

Approach
- Attack surface mapping: discovery of SPA routes, REST endpoints, and API collections
- Authentication and session testing: login, token handling, privilege boundaries
- Authorization testing: object-level access control and function-level restrictions across API resources
- Injection testing: SQL injection across search and authentication endpoints with evidence-based validation
- Client-side security testing: DOM-based XSS validation and token theft impact verification
- Information disclosure review: exposed files, administrative configuration endpoints, and error handling/stack traces

Validation standard
Only vulnerabilities with reproducible evidence and clear security impact were reported.

# Technical Analysis

Severity model
Severity reflects exploitability and impact to confidentiality, integrity, and availability in a realistic attacker model.

Confirmed findings
vuln-0001 (Critical): Unauthenticated SQL Injection in GET /rest/products/search (q)
The product search parameter is injectable (error/boolean/UNION), enabling database enumeration and extraction of sensitive data including administrative credentials (hashes).

vuln-0003 (Critical): SQL Injection in POST /rest/user/login (email) Enables Authentication Bypass
A crafted email value bypasses authentication and returns a valid admin JWT, enabling immediate administrative access.

vuln-0002 (Critical): Privilege Escalation via Mass Assignment in POST /api/Users
The registration endpoint accepts client-controlled role assignment, allowing a new account to be created as an administrator and then authenticated to obtain an admin JWT.

vuln-0007 (Critical): DOM-based XSS in /#/search via query parameter q
User-controlled query parameter content is inserted into a trusted HTML sink, enabling arbitrary JavaScript execution and theft of JWTs stored in localStorage.

vuln-0005 (High): Broken Object-Level Authorization Enables Cross-User Basket Access and Modification
Authenticated customers can access other users’ baskets by ID, enumerate basket items across users, and modify or delete other users’ basket items. Cross-user feedback deletion was also demonstrated.

vuln-0006 (High): Broken Access Control in /api/Users Enables User Enumeration and Admin Profile Access
Any authenticated customer can enumerate the entire user directory and retrieve arbitrary user profiles including the administrator account.

vuln-0004 (High): Sensitive Information Disclosure via Exposed /ftp, Unauthenticated Admin Configuration, and Stack Trace Leakage
Unauthenticated access to /ftp provides directory listing and downloadable sensitive artifacts (including a KeePass database). Administrative configuration/version endpoints are accessible without authentication, and verbose JSON stack traces disclose internal implementation details and filesystem/module paths.

Systemic root causes
- Unsafe database query construction and insufficient input handling
- Inconsistent and missing server-side authorization checks (object and function level)
- Over-trusting client-side data and unsafe HTML rendering patterns
- Exposure of sensitive operational artifacts and overly verbose error handling
- High-risk token storage strategy (JWTs in localStorage) amplifying XSS impact

# Recommendations

Immediate (0–7 days)
- Eliminate SQL injection in /rest/products/search and /rest/user/login by using parameterized queries/prepared statements. Add regression tests for injection payloads and deploy centralized query-building patterns that prevent string concatenation.
- Remediate the mass assignment role escalation in /api/Users by enforcing server-side allowlisting of permitted fields and hard-coding default role assignment for new users (e.g., “customer”). Reject or ignore privileged fields (role, tokens, admin flags) in all client-submitted payloads.
- Remediate DOM XSS in /#/search by removing bypass/trust APIs for user-controlled data and avoiding HTML sinks (innerHTML). Encode search terms as text. Add defense-in-depth controls including a restrictive Content Security Policy (CSP) and consider Trusted Types where applicable.
- Reduce token theft blast radius by migrating JWT storage from localStorage to secure cookies (HttpOnly, Secure, SameSite) where feasible, and rotate/revoke tokens after fixes are deployed.

Short-term (1–4 weeks)
- Implement centralized authorization enforcement (deny-by-default) for all /api/* and /rest/* resources:
  - Scope list endpoints (e.g., basket items) to the authenticated principal
  - Enforce per-object ownership checks on read and write operations
  - Restrict user directory endpoints to administrative roles; restrict /api/Users/{id} to self-access unless privileged
- Lock down sensitive operational endpoints:
  - Disable /ftp directory listing and require authorization for any non-public content
  - Restrict /rest/admin/* endpoints to administrative roles and minimize exposed configuration fields
  - Disable stack traces and internal path disclosure in production error responses
- Treat exposed artifacts as compromised:
  - Remove/relocate sensitive files from web-accessible locations
  - Rotate any secrets/credentials potentially stored in exposed files (e.g., KeePass database) and audit for misuse

Medium-term (1–3 months)
- Establish a secure SDLC control set:
  - Add automated security tests for authorization (BOLA), mass assignment, and injection
  - Implement consistent server-side input validation and output encoding standards
  - Improve monitoring and alerting for anomalous authentication events, injection patterns, and authorization failures
- Conduct a focused retest after remediation of the immediate items to confirm elimination of SQLi, XSS, privilege escalation, and cross-user access paths.

