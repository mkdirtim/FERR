# BadStore (http://badstore:80) – Pentest Findings

Scope: `http://badstore:80` (HTTP only)

## Finding 1: SQL Injection (error-based indicator) in product search
**Severity:** High  
**Category:** Injection / SQLi (CWE-89)

### Description
The `searchquery` parameter in the search function appears to be concatenated into a backend SQL query without proper sanitization/parameterization. Submitting a single quote triggers a database syntax error originating from the MySQL/MariaDB driver (`DBD::mysql`). This is a strong indicator of SQL injection.

### Affected endpoint
- `GET /cgi-bin/badstore.cgi?action=search&searchquery=...`

### Steps to reproduce (safe)
1. Request a normal search:
   ```bash
   curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=test'
   ```
2. Trigger the SQL error with a quote:
   ```bash
   curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=%27'
   ```
3. Observe the returned error message containing MySQL/MariaDB syntax error:
   - `DBD::mysql::st execute failed: You have an error in your SQL syntax ...`
   - Error reveals file path and line: `/data/apache2/cgi-bin/badstore.cgi line 242`

### Impact
An attacker may be able to manipulate the SQL query to bypass intended search constraints, extract sensitive data (users/orders/products), or modify data depending on DB permissions.

### Recommended remediation
- Use parameterized queries / prepared statements for all SQL interactions.
- Apply server-side input validation with allowlists for expected search formats.
- Implement centralized error handling to avoid returning raw database errors.

---

## Finding 2: Verbose application/database error disclosure
**Severity:** Medium  
**Category:** Information Exposure (CWE-209)

### Description
The application returns detailed backend error messages to the client, including:
- Database driver (`DBD::mysql`), DB type (MariaDB/MySQL)
- Full filesystem path to CGI script (`/data/apache2/cgi-bin/badstore.cgi`)
- Source line number (`line 242`)

This information increases attacker efficiency for targeted exploitation (SQLi tuning, path guessing, tech fingerprinting).

### Affected endpoint
- `GET /cgi-bin/badstore.cgi?action=search&searchquery=%27`

### Steps to reproduce
```bash
curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=%27'
```

### Impact
Improves exploitability of other vulnerabilities (notably SQLi) and leaks internal implementation details.

### Recommended remediation
- Disable detailed error output in production.
- Return generic user-facing errors; log full stack traces server-side only.

---

## Finding 3: Sensitive path hints exposed via robots.txt
**Severity:** Low  
**Category:** Security Misconfiguration / Information Disclosure

### Description
`/robots.txt` discloses potentially sensitive directories (e.g., `/backup`, `/supplier`, `/upload`, `/cgi-bin`). While not a vulnerability by itself, it provides an attacker with a focused list of high-value paths to probe.

### Evidence
```bash
curl -sS http://badstore/robots.txt
```
Contains disallow entries:
- `/backup`
- `/supplier`
- `/upload`
- `/cgi-bin`

### Impact
Facilitates reconnaissance and targeted enumeration.

### Recommended remediation
- Do not rely on `robots.txt` for access control.
- Consider removing sensitive path hints from `robots.txt` (or ensure robust authz on those paths).

---

## Notes / Observations
- Root (`/`) immediately redirects to `/cgi-bin/badstore.cgi` via HTML meta refresh.
- Server header discloses platform: `Apache/2.4.65 (Debian)` (consider minimizing banner where feasible).

