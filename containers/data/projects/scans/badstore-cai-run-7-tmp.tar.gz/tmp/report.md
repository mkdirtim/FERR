# BadStore (http://badstore:80) – Pentest Findings

Date: 2026-02-26  
Scope: `http://badstore:80`  
Tester: automated assistant

## High – SQL Injection (error-based) in search
**Description**: The product search parameter appears concatenated into a SQL query without proper parameterization/escaping. Submitting a single quote triggers a backend MariaDB syntax error, indicating SQL injection.

- **Affected endpoint**: `GET /cgi-bin/badstore.cgi?action=search&searchquery=...`

**Steps to reproduce**:
1. Request:
   ```bash
   curl -i "http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=%27"
   ```
2. Observe the HTTP 500 response with a database error.

**Evidence (excerpt)**:
- `DBD::mysql::st execute failed: You have an error in your SQL syntax ... near '''' IN (itemnum,sdesc,ldesc)' ... at /data/apache2/cgi-bin/badstore.cgi line 242.`

**Impact**: Depending on DB permissions and query context, an attacker may be able to extract sensitive data (users/orders), bypass authentication logic, and potentially write data.

**Recommended remediation**:
- Use parameterized queries/prepared statements.
- Centralize input validation and output encoding.
- Add WAF rules only as compensating control.

**References**: CWE-89, OWASP A03:2021 Injection

---

## Medium – Information disclosure via verbose application errors
**Description**: The application returns detailed exception traces including DB driver, query fragments, filesystem paths, and line numbers.

- **Affected endpoint**: `GET /cgi-bin/badstore.cgi?action=search&searchquery=%27`

**Steps to reproduce**:
1. Request as above.
2. Observe full error output including internal path `/data/apache2/cgi-bin/badstore.cgi` and code line number.

**Impact**: Helps attackers fingerprint stack (Perl/DBD::mysql/MariaDB) and speed exploitation (e.g., SQLi tuning, LFI/RFI targeting).

**Recommended remediation**:
- Disable debug/stack traces in production; return generic error pages.
- Log full errors server-side only.

**References**: CWE-209

---

## Low – Sensitive/hidden paths disclosed via robots.txt
**Description**: `robots.txt` discloses potentially sensitive directories (`/backup`, `/supplier`, `/upload`, `/cgi-bin`). While not a direct vuln, it materially assists attackers.

- **Affected asset**: `GET /robots.txt`

**Steps to reproduce**:
```bash
curl -sS http://badstore/robots.txt
```

**Impact**: Improves discovery of admin/supplier/upload/backup functionality and increases attack surface.

**Recommended remediation**:
- Do not rely on `robots.txt` for access control.
- Remove sensitive paths from `robots.txt` and enforce server-side authorization.

**References**: CWE-200

---

## Notes / partially validated observations
- **Guestbook input**: Guestbook submission endpoint exists:
  - `POST /cgi-bin/badstore.cgi?action=doguestbook` with fields `name`, `email`, `comments`.
  - A basic `<script>alert(1)</script>` payload was submitted successfully (HTTP 200), but it was **not observed reflected** on `action=viewprevious` during this quick pass. This needs deeper validation for stored/reflected XSS across guestbook render views.

---

## Business-Logic Abuse Backlog (targeted test cases)
1. **Search SQLi escalation** – target: `action=search`
   - Preconditions: anonymous
   - Abuse idea: UNION/time-based extraction; bypass filters
   - Validate: try `' OR 1=1-- -`, time delays, UNION column count
   - Success signal: altered result set / time delay / data leakage
   - Impact: data exfiltration/auth bypass

2. **Error handling bypass** – target: `action=search`
   - Preconditions: anonymous
   - Abuse idea: force errors to leak schema/table names
   - Validate: crafted payloads to trigger different SQL errors
   - Success signal: schema/table hints in responses
   - Impact: accelerates DB compromise

3. **Guestbook stored XSS** – target: `action=doguestbook` → `action=viewprevious`
   - Preconditions: anonymous
   - Abuse idea: persist script in comments/name
   - Validate: submit payloads; inspect rendering; check HTML encoding
   - Success signal: payload appears unescaped in view page
   - Impact: session theft / defacement

4. **Guestbook HTML injection** – target: guestbook rendering
   - Preconditions: anonymous
   - Abuse idea: inject `<img onerror=...>` / attribute breakouts
   - Validate: submit various encodings; check output context
   - Success signal: DOM execution in victim browser
   - Impact: account compromise

5. **Account workflow** – target: `action=loginregister` / `action=myaccount`
   - Preconditions: create user (if allowed)
   - Abuse idea: enumerate users via error messages / reset flow
   - Validate: compare responses for existing vs non-existing usernames
   - Success signal: distinguishable responses/timing
   - Impact: credential stuffing aid

6. **Cart tampering** – target: `action=cartview` and add-to-cart flows
   - Preconditions: anonymous or user
   - Abuse idea: manipulate price/quantity/item id parameters
   - Validate: intercept requests; change item/price fields
   - Success signal: cart totals reflect tampering
   - Impact: financial loss

7. **Supplier login brute-force defenses** – target: `action=supplierlogin`
   - Preconditions: anonymous
   - Abuse idea: no rate limit/lockout
   - Validate: low-rate repeated attempts; watch for blocking
   - Success signal: unlimited attempts/no backoff
   - Impact: supplier account takeover risk

8. **Supplier proc access control** – target: `action=supplierproc`
   - Preconditions: anonymous
   - Abuse idea: direct access to supplier functions without auth
   - Validate: request supplier endpoints unauthenticated
   - Success signal: sensitive supplier data/actions accessible
   - Impact: business partner compromise

9. **Hidden directories** – target: `/backup`, `/upload`, `/supplier`
   - Preconditions: anonymous
   - Abuse idea: directory listing / exposed backups
   - Validate: HEAD/GET common backup filenames, index listing
   - Success signal: downloadable archives/configs
   - Impact: source/config leakage → full compromise

10. **scanbot functionality misuse** – target: `/scanbot/scanbot.html`
   - Preconditions: anonymous
   - Abuse idea: SSRF-style “scanner” features (URL fetch)
   - Validate: locate URL parameters; attempt internal fetches safely
   - Success signal: server fetches attacker-controlled URL
   - Impact: SSRF → internal data exposure

