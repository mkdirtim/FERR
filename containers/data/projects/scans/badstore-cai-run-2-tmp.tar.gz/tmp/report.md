# BadStore (http://badstore:80) - Findings Report

Scope: **http://badstore:80** only

## High - SQL Injection (search)
**Affected endpoint:** `GET /cgi-bin/badstore.cgi?action=search&searchquery=...`

**Description:**
Search input is incorporated into an SQL query without proper handling. Submitting a single quote triggers a server error and the application discloses the backend SQL query in the response body.

**Evidence / Steps to reproduce:**
1. Request a normal search:
   - `curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=test' | head`
2. Trigger the issue with a single quote:
   - `curl -i 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=%27'`
3. Observe `HTTP 500` and SQL query disclosure in the HTML:
   - `SELECT itemnum, sdesc, ldesc, price FROM itemdb WHERE '' IN (itemnum,sdesc,ldesc)`

**Impact:**
An attacker may be able to manipulate the query to read/alter data (products, orders, accounts) and potentially achieve authentication bypass depending on other code paths.

**Remediation:**
Use parameterized queries/prepared statements; strictly validate/encode input; remove debug output that prints SQL; implement centralized error handling.

**References:** OWASP A03:2021 Injection, CWE-89

---

## High - Reflected XSS (search)
**Affected endpoint:** `GET /cgi-bin/badstore.cgi?action=search&searchquery=...`

**Description:**
User-controlled `searchquery` is reflected into the HTML response without output encoding. Payloads appear in the response unescaped.

**Steps to reproduce:**
1. Request:
   - `curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=%3Cscript%3Ealert(1)%3C%2Fscript%3E'`
2. Confirm reflection:
   - Response contains: `<script>alert(1)</script>` (observed at line ~57 in response)

**Impact:**
Victim browser code execution (session theft, account takeover via CSRF-like actions, defacement) if a victim follows a crafted link.

**Remediation:**
Contextual output encoding (HTML/attribute/JS contexts); consider a strict CSP; sanitize/validate input; avoid reflecting raw user input.

**References:** OWASP A03:2021 Injection, CWE-79

---

## Medium - Information Disclosure (debug SQL query in response)
**Affected endpoint:** `GET /cgi-bin/badstore.cgi?action=search&searchquery=...`

**Description:**
The application prints internal comments and the full SQL query in the response ("Comment the $sql line out after troubleshooting is done"). This significantly lowers exploitation effort for injection vulnerabilities.

**Steps to reproduce:**
- `curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=test' | grep -i 'SELECT itemnum' -n`

**Impact:**
Reveals schema/field names and query structure enabling faster SQLi exploitation and targeted attacks.

**Remediation:**
Remove debug output and internal comments from production responses; implement generic error pages.

**References:** CWE-200

---

## Low - Missing common security headers
**Affected:** `GET /` (and likely others)

**Description:**
Responses are missing common hardening headers such as `Content-Security-Policy`, `X-Frame-Options`, `X-Content-Type-Options`, and `Strict-Transport-Security` (HSTS).

**Evidence:**
- `GET http://badstore/` lacks: CSP, XFO, XCTO, HSTS.

**Impact:**
Increases exploitability of client-side issues (XSS impact, clickjacking, MIME sniffing). Not a standalone compromise.

**Remediation:**
Add baseline headers; enforce HTTPS and HSTS if TLS is supported.

---

## Informational - Sensitive paths disclosed via robots.txt
**Affected:** `GET /robots.txt`

**Description:**
`robots.txt` lists potentially sensitive directories (`/backup`, `/supplier`, `/upload`, `/cgi-bin`). This is not a vulnerability by itself but aids attackers in discovery.

**Evidence:**
- `curl -sS http://badstore/robots.txt`

**Remediation:**
Do not rely on `robots.txt` for access control; restrict access to sensitive paths with authz controls; consider removing unnecessary entries.

