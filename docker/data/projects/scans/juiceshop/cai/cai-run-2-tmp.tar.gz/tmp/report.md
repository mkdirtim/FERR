# Penetration Test Findings – http://juiceshop:3000

Date: 2026-02-13  
Tester: API Assistant (web app pentest)  
Scope: `http://juiceshop:3000` (HTTP)

## Summary
Initial passive recon against the landing page (`/`) identified several security hardening gaps and an overly-permissive CORS policy. No intrusive scanning or authenticated testing was performed yet.

## Findings

### 1) Overly permissive CORS on main application
**Severity:** Medium  
**Affected:** `GET http://juiceshop:3000/` (and likely other responses)

**Description**
The application responds with `Access-Control-Allow-Origin: *`. If any endpoints rely on cookies/bearer tokens (or expose sensitive data to browser contexts), wildcard ACAO can enable cross-origin reads from arbitrary origins (especially if combined with misconfigured `Access-Control-Allow-Credentials` on other endpoints, or if tokens are stored in accessible browser storage).

**Evidence**
Response header observed:
- `Access-Control-Allow-Origin: *`

**Impact**
Potential cross-origin data exposure and increased blast radius for any XSS/token leakage scenarios.

**Remediation**
- Restrict `Access-Control-Allow-Origin` to trusted origins.
- Ensure `Access-Control-Allow-Credentials` is not enabled alongside wildcard origins.
- Review CORS across API endpoints, not just `/`.

**References**
- OWASP CORS: https://owasp.org/www-community/attacks/CORS_OriginHeaderScrutiny

---

### 2) Missing modern clickjacking/XSS mitigation headers (CSP) and TLS enforcement (HSTS)
**Severity:** Low (context-dependent; can be Medium if sensitive authenticated flows exist)  
**Affected:** `GET http://juiceshop:3000/`

**Description**
The response does not include `Content-Security-Policy` (CSP) or `Strict-Transport-Security` (HSTS). While some legacy headers are present (`X-Frame-Options: SAMEORIGIN`, `X-Content-Type-Options: nosniff`), lack of CSP increases XSS exploitability and lack of HSTS reduces protection against SSL stripping (when served over HTTPS in production).

**Evidence**
Missing headers reported:
- `Content-Security-Policy`
- `Strict-Transport-Security`

**Impact**
- CSP absence increases likelihood and impact of XSS (should one exist) by allowing broader script execution.
- HSTS absence reduces protection against downgrade/SSL-stripping (relevant when HTTPS is used).

**Remediation**
- Implement a restrictive CSP (start with report-only, then enforce).
- Enable HSTS on HTTPS deployments (not applicable to plain HTTP-only setups).

**References**
- OWASP Secure Headers Project: https://owasp.org/www-project-secure-headers/

---

### 3) Information disclosure via custom header
**Severity:** Informational  
**Affected:** `GET http://juiceshop:3000/`

**Description**
A non-standard header (`X-Recruiting`) discloses an internal route `/#/jobs`. While low risk by itself, it increases discoverability of application areas and can aid targeted testing.

**Evidence**
- `X-Recruiting: /#/jobs`

**Impact**
Minor increase in attack surface discovery.

**Remediation**
- Remove non-essential informational headers from production responses.

## Next steps (proposed)
- Map the API surface (e.g., `/api/*`, `/rest/*`) and JS-discovered endpoints.
- Identify authentication/session model and test for IDOR/BAC across key objects (users, orders, baskets).
- Validate CORS across API endpoints (especially any returning user data) and check credentialed CORS.

