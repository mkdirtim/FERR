# BadStore Web App Pentest Report (http://badstore:80)

Date: 2026-02-13  
Scope: **http://badstore:80** only

## Executive summary
BadStore is intentionally insecure and exposes several high-risk weaknesses even from unauthenticated browsing. The application is primarily driven by `/cgi-bin/badstore.cgi` with numerous action-based flows (search, guestbook, cart, previous orders, supplier area). Initial testing focused on low-noise, read-only reconnaissance.

## Observed application entry points
- `/` performs an immediate meta refresh to: `/cgi-bin/badstore.cgi`
- Core app: `/cgi-bin/badstore.cgi` (parameter-driven via `action=` and other query params)
- Embedded header/cart widget: `/cgi-bin/bsheader.cgi` (loaded via iframe)

## Findings

### 1) Information disclosure: Web server version banner
**Severity:** Low (defense-in-depth)  
**Affected:** `http://badstore:80/` and general responses

**Description:**
The server discloses detailed version information in the `Server` response header.

**Evidence (response header):**
- `Server: Apache/2.4.65 (Debian)`

**Steps to reproduce:**
```bash
curl -I http://badstore:80/
```

**Impact:**
Helps attackers tailor exploits to known Apache/Debian vulnerabilities and fingerprint the stack.

**Remediation:**
Configure Apache to minimize banner leakage (e.g., `ServerTokens Prod` and `ServerSignature Off`) and consider reverse proxy normalization.

**References:**
- OWASP ASVS V14 (Configuration)

---

### 2) Sensitive path disclosure via `robots.txt`
**Severity:** Medium (enables targeted discovery)  
**Affected:** `http://badstore:80/robots.txt`

**Description:**
`robots.txt` reveals potentially sensitive directories (`/backup`, `/supplier`, `/upload`, and `/cgi-bin`). While `robots.txt` is not an access control mechanism, it is commonly used by attackers for quick enumeration.

**Evidence:**
`/robots.txt` contains:
- `Disallow: /backup`
- `Disallow: /supplier`
- `Disallow: /upload`
- `Disallow: /cgi-bin`

**Steps to reproduce:**
```bash
curl http://badstore:80/robots.txt
```

**Impact:**
Reduces attacker effort and increases likelihood of discovering exposed backups, supplier portals, or upload areas.

**Remediation:**
Do not list sensitive locations in `robots.txt`. Enforce authentication/authorization on sensitive paths and ensure backups are not web-accessible.

**References:**
- OWASP WSTG-INFO-02 (Fingerprint Web Server)

---

### 3) Potential input-driven vulnerabilities due to parameterized CGI design (follow-up required)
**Severity:** TBD (likely Medium–High depending on validation)  
**Affected:** `http://badstore:80/cgi-bin/badstore.cgi`

**Description:**
The application is heavily parameter-driven (e.g., `action=search` and `searchquery=`). Historically, CGI apps with query-string-driven routing and minimal validation are prone to reflected XSS, injection, and business logic flaws.

**Observed evidence:**
- Search form submits `GET /cgi-bin/badstore.cgi?action=search&searchquery=<user input>`

**Low-noise validation plan:**
- Reflected XSS check: inject harmless markers in `searchquery` and confirm encoding.
- Injection checks: baseline responses and error handling (no destructive payloads).
- Authorization checks: attempt unauthenticated access to `action=viewprevious`, `action=myaccount`, supplier actions.

**Remediation:**
Ensure strict server-side input validation and contextual output encoding; add authorization checks per action; implement centralized security controls (WAF rules are not a substitute).

**References:**
- OWASP WSTG-INPV (Input Validation)
- OWASP Top 10: A03 Injection, A01 Broken Access Control, A07 XSS

## Notes / limitations
- This report reflects **initial reconnaissance** and a small amount of unauthenticated content review.
- No high-volume scanning or destructive tests were performed.

