# BadStore Web App Pentest Report (http://badstore:80)

Date: 2026-02-13  
Tester: API Assistant (web app pentest)

## Scope
- In scope: `http://badstore:80` only

## High-level recon summary
- Web server: `Apache/2.4.65 (Debian)`
- Entry point `/` performs an immediate client-side redirect to `/cgi-bin/badstore.cgi`.
- Application appears to be **BadStore.net v1.2.3s** (from HTML title).

## Findings

### 1) Sensitive paths disclosed via robots.txt (Information Disclosure)
**Severity:** Low

**Description**
`/robots.txt` discloses several interesting paths that are likely sensitive/administrative or contain non-public content (`/backup`, `/supplier`, `/upload`, `/cgi-bin`). While robots.txt is not an access control mechanism, it often provides an attacker with a prioritized enumeration list.

**Affected assets / endpoints**
- `GET /robots.txt`
- Disclosed paths: `/backup`, `/supplier`, `/upload`, `/cgi-bin`

**Evidence**
- `http://badstore/robots.txt` contains:
  - `Disallow: /backup`
  - `Disallow: /cgi-bin`
  - `Disallow: /supplier`
  - `Disallow: /upload`

**Impact**
- Reduces attacker effort by pointing directly at potentially sensitive directories and functionality.

**Remediation**
- Do not rely on `robots.txt` to hide sensitive functionality.
- Remove sensitive entries if not needed; ensure proper authentication/authorization on sensitive paths.

**References**
- OWASP: Robots.txt and Information Leakage

---

### 2) Publicly reachable `/backup/` directory (Potential sensitive data exposure)
**Severity:** Medium (potentially High depending on contents)

**Description**
The `/backup/` path is reachable and returns `200 OK`. Even though the directory index currently returns an empty body (Content-Length: 0), the existence of a reachable backup directory is a common source of accidental exposure (database dumps, source code archives, config files, etc.).

**Affected assets / endpoints**
- `GET /backup/`

**Steps to reproduce**
1. Request: `curl -i http://badstore/backup/`
2. Observe `HTTP/1.1 200 OK`.

**Observed behavior (evidence)**
- Response status: `200 OK`
- Headers include `Last-Modified` and `ETag` for an empty response.

**Impact**
- If backup artifacts exist under this path (e.g., `.zip`, `.tar.gz`, `.sql`, `.bak`), they could expose credentials, code, and customer/order data.

**Remediation**
- Remove the backup directory from the web root.
- Enforce deny-by-default at the web server for backup file extensions and backup directories.
- Add CI/CD checks to prevent publishing backup artifacts.

**References**
- CWE-552: Files or Directories Accessible to External Parties

---

### 3) Server and app version information disclosure
**Severity:** Low

**Description**
The server header discloses exact web server version and OS family, and the application home page discloses the app version (`BadStore.net v1.2.3s`). While not a vulnerability alone, it increases the likelihood of targeted exploitation against known issues.

**Affected assets / endpoints**
- `GET /` (Server header)
- `GET /cgi-bin/badstore.cgi` (HTML title)

**Evidence**
- `Server: Apache/2.4.65 (Debian)`
- HTML title: `Welcome to BadStore.net v1.2.3s - The most insecure store on the 'Net!'`

**Impact**
- Helps attackers tailor exploits and reduces reconnaissance time.

**Remediation**
- Configure Apache to minimize version disclosure (e.g., `ServerTokens Prod`, `ServerSignature Off`).
- Remove or avoid exposing precise app version strings in public pages.

**References**
- OWASP: Information Exposure Through an Error Message / Version disclosure

---

## Notes / observed attack surface (not yet fully tested)
- Main app endpoint: `/cgi-bin/badstore.cgi` supports actions via query parameter (observed):
  - `action=search` with parameter `searchquery` (candidate for injection/XSS)
  - `action=cartview`, `action=guestbook`, `action=viewprevious`, `action=myaccount`, `action=loginregister`
- Additional CGI: `/cgi-bin/bsheader.cgi` embedded via iframe (cart header)
- `/supplier/` returns `403 Forbidden` (exists but restricted)
- `/upload/` currently returns `404 Not Found`

## Next steps (if you want deeper validation)
- Enumerate `action=` values and parameters on `badstore.cgi` and associated CGIs.
- Targeted tests: reflected/stored XSS (search/guestbook), SQLi in product/cart/order flows, IDOR in `viewprevious`/order history, auth/session weaknesses in `loginregister` and `myaccount`.
