# BadStore WebApp Pentest Report (http://badstore:80)

Date: 2026-02-13  
Tester: automated red-team assistant  
Scope: **http://badstore:80** only

## Executive Summary
BadStore exposes critical input-validation flaws on the main `badstore.cgi` application, including **SQL injection** in the product search and **reflected XSS**. The search endpoint also **leaks raw SQL query strings**, significantly aiding exploitation.

## Target Overview
- Base: `http://badstore/` → meta refresh to `/cgi-bin/badstore.cgi`
- Server header: `Apache/2.4.65 (Debian)`

---

## Finding 1: SQL Injection in Search Parameter
**Severity: Critical**  
**Category:** OWASP A03:2021 Injection / CWE-89

### Description
The `searchquery` parameter is directly concatenated into a SQL statement used for item search. A boolean-based payload (`' OR 1=1--`) causes the application to return the full item list, demonstrating SQL injection.

### Affected endpoint
- `GET /cgi-bin/badstore.cgi?action=search&searchquery=...`

### Steps to reproduce
1. Request with benign input:
   ```bash
   curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=test'
   ```
2. Request with SQLi payload:
   ```bash
   curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=%27%20OR%201%3D1--%20'
   ```
3. Observe the response now contains many/all catalog items (e.g., item numbers 1000..1014, 9999) and the heading:
   `The following items matched your search criteria:`

### Evidence (observed)
- Payload: `searchquery=' OR 1=1-- `
- Response included a full HTML table of items, indicating query logic bypass.

### Impact
Attackers can potentially:
- Exfiltrate database contents (users/orders/payment data depending on DB schema)
- Bypass intended search logic
- Potentially modify data if stacked queries or writable contexts exist

### Recommended remediation
- Use parameterized queries / prepared statements (no string concatenation)
- Apply strict server-side input validation
- Implement least-privileged DB user for the application
- Add centralized error handling (avoid leaking SQL)

---

## Finding 2: Reflected Cross-Site Scripting (XSS) in Search
**Severity: High**  
**Category:** OWASP A03:2021 Injection / CWE-79

### Description
User-controlled input in `searchquery` is reflected back into the HTML response without encoding, allowing JavaScript injection.

### Affected endpoint
- `GET /cgi-bin/badstore.cgi?action=search&searchquery=...`

### Steps to reproduce
1. Send an XSS payload:
   ```bash
   curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=%3Cscript%3Ealert(1)%3C%2Fscript%3E'
   ```
2. Observe the response reflects the payload inside the page content:
   `... WHERE '<script>alert(1)</script>' IN (itemnum,sdesc,ldesc)`

### Impact
An attacker can craft a link that, when visited by a victim:
- Executes arbitrary JS in the victim’s browser
- Steals session data (if any cookies/tokens are present)
- Performs actions as the victim (depending on auth/session model)

### Recommended remediation
- Contextual output encoding (HTML-encode untrusted input)
- Consider a strong Content Security Policy (CSP) as defense-in-depth

---

## Finding 3: SQL Query/Debug Information Disclosure in Search Results
**Severity: Medium**  
**Category:** Security Misconfiguration / CWE-209

### Description
The search page discloses the backend SQL statement directly in the HTML response (comment indicates troubleshooting was left enabled). This reveals table/column names and query structure, greatly simplifying SQLi exploitation.

### Affected endpoint
- `GET /cgi-bin/badstore.cgi?action=search&searchquery=...`

### Steps to reproduce
1. Request any search:
   ```bash
   curl -sS 'http://badstore/cgi-bin/badstore.cgi?action=search&searchquery=abc'
   ```
2. Observe SQL is printed in the response (example):
   `SELECT itemnum, sdesc, ldesc, price FROM itemdb WHERE 'abc' IN (itemnum,sdesc,ldesc)`

### Impact
- Assists attackers in crafting reliable SQL injection payloads
- Exposes internal implementation details

### Recommended remediation
- Remove debug output from production
- Ensure errors/logging are server-side only

---

## Notes / Additional Observations
- Guestbook form exists (`POST /cgi-bin/badstore.cgi?action=doguestbook`). A basic stored-XSS check was attempted by submitting `<script>alert(1)</script>` in `comments`, but it did **not** immediately appear when reloading the guestbook page. Further testing may be needed to verify whether entries are stored/displayed elsewhere.

