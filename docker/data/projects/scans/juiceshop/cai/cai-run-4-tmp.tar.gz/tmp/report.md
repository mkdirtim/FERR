# OWASP Juice Shop - Pentest Findings (http://juiceshop:3000)

Date: 2026-02-13  
Scope: `http://juiceshop:3000` (only)

## Finding 1: Unauthenticated directory listing & sensitive file exposure via `/ftp`
**Severity:** High

### Description
The path `/ftp` is publicly accessible and returns a directory listing containing internal/confidential documents and other potentially sensitive artifacts. At least one confidential document (`acquisitions.md`) can be retrieved without authentication.

This constitutes an information disclosure and can materially aid attackers (OSINT, credential discovery, internal process exposure, etc.).

### Affected endpoints
- `GET /ftp`
- `GET /ftp/acquisitions.md`

### Steps to reproduce
1. Request the directory listing:
   - `curl -sS http://juiceshop:3000/ftp`
   - Observe HTML title `listing directory /ftp` and links to multiple files.
2. Retrieve a listed document without authentication:
   - `curl -sS http://juiceshop:3000/ftp/acquisitions.md`
   - Observe content including: `# Planned Acquisitions` and `This document is confidential! Do not distribute!`

### Evidence (observed)
- `robots.txt` explicitly disallows `/ftp`:
  - `User-agent: *` / `Disallow: /ftp`
- `/ftp` listing includes entries such as:
  - `ftp/acquisitions.md`
  - `ftp/incident-support.kdbx`
  - `ftp/encrypt.pyc`
  - `ftp/coupons_2013.md.bak` (blocked by extension filter, but the filename is still disclosed)

### Impact
Unauthenticated users can browse and download internal documentation. Even when some extensions are blocked on download, filenames and directory structure are disclosed and may enable further compromise.

### Recommended remediation
- Disable directory listing on `/ftp`.
- Require authentication/authorization for any internal documents.
- Remove sensitive artifacts from the web root/static hosting.
- Consider adding allowlist-based routing for static assets rather than exposing filesystem-like listings.

### References
- OWASP ASVS V1/V4 (Access control / Sensitive data exposure)
- CWE-548: Exposure of Information Through Directory Listing

---

## Finding 2: Overly permissive CORS on unauthenticated content
**Severity:** Low

### Description
Responses include `Access-Control-Allow-Origin: *` (observed on `/` and `/ftp`). While not inherently exploitable alone (depends on presence of credentialed endpoints and sensitive responses), this configuration can increase the blast radius of client-side data exfiltration if any sensitive unauthenticated resources are present (as demonstrated by the exposed `/ftp/acquisitions.md`).

### Affected endpoints (observed)
- `GET /`
- `GET /ftp`

### Steps to reproduce
- `curl -sS -D- http://juiceshop:3000/ -o /dev/null | grep -i access-control-allow-origin`
- `curl -sS -D- http://juiceshop:3000/ftp -o /dev/null | grep -i access-control-allow-origin`

### Impact
Third-party sites can read responses from these endpoints via browser-based cross-origin requests. If additional sensitive unauthenticated resources exist, they can be exfiltrated from a victim’s browser.

### Recommended remediation
- Restrict CORS to trusted origins where needed.
- Avoid `*` unless the endpoint is explicitly intended to be publicly readable cross-origin.

### References
- OWASP CORS guidance

