# BadStore Web App Penetration Test Report

**Target:** http://badstore:80  
**Date:** 2026-02-13  
**Tester:** API assistant (red-team)  

## Executive summary
BadStore contains multiple critical authorization and session-management weaknesses that allow an unauthenticated user to create an account with elevated role (`A`) and obtain a trivially forgeable authentication cookie (`SSOid`). This enables privilege escalation and likely full compromise of protected application functionality.

## Scope
- In-scope: `http://badstore:80/*`

## Methodology (high level)
- Low-noise, manual HTTP testing with `curl`
- Review of HTML forms/parameters
- Safe privilege/role tampering validation

---

## Finding 1: Parameter tampering allows self-registration with elevated role (Privilege Escalation)
**Severity:** Critical  
**Category:** Broken Access Control / Mass Assignment (OWASP A01:2021)  

### Description
The registration form includes a hidden parameter `role` with default value `U`. The server trusts this client-controlled parameter. By changing it to `A`, a newly created user is granted elevated privileges.

### Affected endpoint
- `POST /cgi-bin/badstore.cgi?action=register`

### Steps to reproduce
1. Browse login/register page and note hidden role field:
   - `GET /cgi-bin/badstore.cgi?action=loginregister`
   - Contains: `<input type="hidden" name="role" value="U" />`
2. Register while tampering `role` to `A`:
   ```bash
   curl -s -X POST 'http://badstore/cgi-bin/badstore.cgi?action=register' \
     -d 'fullname=tester&email=tester%40example.com&passwd=Passw0rd&hint=h&role=A' \
     -c /tmp/cookies.txt
   ```
3. Access My Account and observe the role reflected as `A` in hidden field:
   ```bash
   curl -s 'http://badstore/cgi-bin/badstore.cgi?action=myaccount' -b /tmp/cookies.txt | grep -n 'name="role"'
   ```
   Observed:
   - `<input type="hidden" name="role" value="A"  />`

### Impact
Any attacker can create an admin/elevated account without authorization, enabling takeover of privileged functions and potential data exposure/manipulation.

### Recommended remediation
- Do not accept `role` (or any privilege/entitlement fields) from the client during registration.
- Enforce role assignment server-side using allowlists and secure defaults.
- Add authorization checks on all privileged actions independent of UI.

---

## Finding 2: Weak authentication cookie (SSOid) is base64-encoded, contains role, and appears forgeable
**Severity:** High (potentially Critical if accepted without server-side validation)  
**Category:** Broken Authentication / Session Management (OWASP A07:2021)  

### Description
The `SSOid` cookie value is base64-encoded data that includes user identity fields and the role. This is not a secure session identifier format by itself and strongly suggests the application is trusting client-controlled identity/role data.

Observed cookie (after registration with role `A`):
- `Set-Cookie: SSOid=<base64> ; path=/`

Decoding the cookie reveals:
- `tester@example.com:d41e98d1eafa6d6011d3a70f1a5b92f0:tester:A`

### Evidence / reproduction
1. Register/login to obtain `SSOid`.
2. Decode:
   ```bash
   python3 - <<'PY'
import base64,urllib.parse
v='dGVzdGVyQGV4YW1wbGUuY29tOmQ0MWU5OGQxZWFmYTZkNjAxMWQzYTcwZjFhNWI5MmYwOnRlc3RlcjpB'
print(base64.b64decode(v).decode())
PY
   ```

### Impact
If the server does not cryptographically sign and validate this cookie, an attacker may be able to forge sessions and escalate privileges by crafting their own `SSOid` values (e.g., set role to `A`, change email/user).

### Recommended remediation
- Use opaque, random, server-side session identifiers.
- If using a structured token, use authenticated encryption or a strong signature (e.g., HMAC) and validate server-side.
- Mark cookies `HttpOnly`, `Secure` (when on HTTPS), and `SameSite` appropriately.

---

## Finding 3: Missing cookie security flags on SSOid
**Severity:** Medium  
**Category:** Session Management Hardening  

### Description
`SSOid` is set without common hardening attributes.

### Evidence
- `Set-Cookie: SSOid=...; path=/`
- Missing: `HttpOnly`, `SameSite`, `Secure` (note: app is HTTP, so `Secure` would require HTTPS)

### Impact
Increases risk of session theft via XSS and cross-site request contexts.

### Recommended remediation
- Add `HttpOnly; SameSite=Lax` (or `Strict` where possible).
- Migrate to HTTPS and add `Secure`.

---

## Notes / Observed attack surface
- Main application is a CGI script:
  - `/cgi-bin/badstore.cgi` with action-driven routing (`?action=...`).
- Observed features/links:
  - `action=cartview`, `action=viewprevious`, `action=myaccount`, `action=supplierlogin`, `action=supplierproc`, `action=supplierportal`.

## Suggested next focused tests (low-noise)
- Attempt to forge `SSOid` with arbitrary `email`/`role` and verify authorization decisions.
- Verify whether supplier-only actions are accessible with role `A` created via registration.
- Check `viewprevious` for IDOR by manipulating order identifiers (if present) and comparing as different users.
- Probe search (`action=search`) for injection/XSS with safe payloads.

