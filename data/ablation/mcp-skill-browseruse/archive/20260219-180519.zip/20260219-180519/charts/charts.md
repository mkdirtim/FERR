# Charts Reference

Two versions of each chart are available. A-PC-2 (safety refusal) is excluded from all analyses; A-CLI cells are marked n=2 throughout.

| Version | Folder | Style |
|---|---|---|
| Academic | `charts/academic/` | Serif fonts (DejaVu Serif), blue/red palette, white background, 300 DPI |
| Anthropic | `charts/anthropic/` | Poppins headings + Lora body, brand blue/orange palette, warm `#faf9f5` background, 300 DPI |

---

## Tier 1 — Core Findings

### Chart 1: Median Cost + Turns Grouped Bar Chart
**File:** `chart1_median_cost_turns.png`

Side-by-side bars per task, MCP vs CLI. Two panels: cost on top, turns on bottom. The headline chart — shows parity on Task A ($0.37 vs $0.37) and the 4–5× gap on Tasks B and C at a glance.

### Chart 2: Individual Runs Dot Plot with Median Line
**File:** `chart2_dotplot_variance.png`

One dot per rep, per cell, with a horizontal median line overlay. Reveals B-MCP's zero variance (7/7/7 turns) vs B-CLI's spread (25/29/37) vs A-MCP's high variance (13/18/24). The variance story that bar charts alone cannot tell.

### Chart 3: Cache Read/Turn vs Total Cost Scatter
**File:** `chart3_cacheread_vs_cost.png`

X = cache_read per turn (thousands), Y = total cost. One point per run, shaped by approach (circle = MCP, square = CLI). All points cluster at ~23–33K/turn on the X axis while spreading widely on Y — visual proof that cost differences are turn-count-driven, not context-size-driven.

---

## Tier 2 — Mechanistic Depth

### Chart 4: Cost Breakdown Stacked Bar
**File:** `chart4_cost_breakdown.png`

Per cell: stacked cache_read cost, input + cache_creation cost, Sonnet output cost, and Haiku subagent cost. For B-CLI and C-CLI, cache_read dominates. For C-MCP, everything is tiny. Shows what you're paying for at the token-component level.

### Chart 5: Haiku Subagent Usage Heatmap
**File:** `chart5_haiku_heatmap.png`

18-cell grid (reps as rows, task+approach as columns), binary color: Haiku used or not. Pattern: B-CLI and C-CLI always fired, B-MCP and C-MCP never. A-CLI Rep 2 marked N/A (excluded refusal). Makes the systematic subagent overhead visible.

---

## Tier 3 — Presentation / Bonus

### Chart 6: Cost vs Interaction Depth Line Chart
**File:** `chart6_cost_vs_depth.png`

Tasks ordered A → B → C on the X axis (decreasing MCP cost, increasing CLI cost). MCP line descends from $0.37 → $0.14 → $0.10. CLI peaks at $0.64 on Task B, then drops to $0.43 on C. Tells the crossover story: the approaches are at parity on simple form tasks, but CLI diverges sharply on interaction-heavy tasks.

### Chart 7: Wall Time Comparison
**File:** `chart7_wall_time.png`

Same grouped-bar structure as Chart 1 but for median wall time in seconds. MCP: 71s / 39s / 26s. CLI: 84s / 142s / 80s. Less dramatic than cost (3.6× on Task B vs 4.5× for cost) but directionally consistent. Reinforces that the turn-count gap translates to real elapsed time, not just billing.

---

## Generation

| Version | Script | Source data |
|---|---|---|
| Academic | `charts_academic.py` | `results.csv` |
| Anthropic | `charts_anthropic.py` | `results.csv` |

Both scripts exclude the refusal run via `df_valid = df[df['run_id'] != 'A-PC-2']`.
