# Tool Isolation Failure — Experiment Validity Assessment

**Date:** 2026-02-19
**Experiment:** playwright-mcp vs playwright-cli token usage comparison (18 runs)
**Status:** Experiment data is partially confounded — re-run required for strict A/B validity

---

## Summary

`--allowedTools` did not enforce exclusive tool-family separation. Both MCP and CLI tools
appeared in runs where they were disallowed by the allowlist, making 9 of 18 runs invalid
for a strict between-approach comparison.

---

## Per-Run Tool Audit

Tool names extracted from all 18 `.session.jsonl` files.

### MCP arm (expected: only `mcp__playwright__*`)

| Run | Tools used | Status |
|-----|-----------|--------|
| A-MCP-1 | `Bash`×9, `Skill`×1, `mcp__playwright__browser_take_screenshot`×1 | **CONTAMINATED** |
| A-MCP-2 | `Bash`×13, `Skill`×1, `mcp__playwright__browser_take_screenshot`×1 | **CONTAMINATED** |
| A-MCP-3 | `mcp__playwright__*`×10, `Skill`×1 | **CONTAMINATED** |
| B-MCP-1 | `mcp__playwright__*` only | PURE |
| B-MCP-2 | `mcp__playwright__*` only | PURE |
| B-MCP-3 | `mcp__playwright__*` only | PURE |
| C-MCP-1 | `mcp__playwright__*` only | PURE |
| C-MCP-2 | `mcp__playwright__*` only | PURE |
| C-MCP-3 | `mcp__playwright__*` only | PURE |

MCP pure: **6/9**. All contamination is in the Task A arm.

### CLI arm (expected: only `Bash`, `Read`, `Write`, `Glob`, `Edit`)

| Run | Tools used | Status |
|-----|-----------|--------|
| A-PC-1 | `mcp__playwright__browser_click`×4, `browser_navigate`×2, `browser_type`×2, `browser_snapshot`×1, `browser_take_screenshot`×1, `Skill`×1 | **CONTAMINATED** |
| A-PC-2 | `Skill`×1 only (no browser actions — likely a refusal or 0-step run) | PURE |
| A-PC-3 | `Bash`×12, `Read`×7, `Skill`×1, `mcp__playwright__browser_snapshot`×1, `browser_take_screenshot`×1 | **CONTAMINATED** |
| B-PC-1 | `Bash`×16, `Read`×5, `Skill`×1, `mcp__playwright__browser_take_screenshot`×1 | **CONTAMINATED** |
| B-PC-2 | `Bash`×21, `Read`×4, `Skill`×1, `mcp__playwright__browser_take_screenshot`×1 | **CONTAMINATED** |
| B-PC-3 | `Bash`×26, `Read`×3, `Skill`×1, `mcp__playwright__browser_take_screenshot`×5 | **CONTAMINATED** |
| C-PC-1 | `Bash`×17, `Skill`×1, `mcp__playwright__browser_snapshot`×1, `Read`×1 | **CONTAMINATED** |
| C-PC-2 | `Bash`×17, `Read`×2, `Skill`×1 | PURE |
| C-PC-3 | `Bash`×18, `Skill`×1, `Read`×1 | PURE |

CLI pure: **3/9**. Contamination is concentrated in Task A (fully mixed) and Task B
(all three runs have a stray MCP screenshot call).

---

## Purity Summary

| Arm | Pure | Contaminated |
|-----|------|-------------|
| MCP (9 runs) | 6 | 3 (all Task A) |
| CLI (9 runs) | 3 | 6 |
| **Total** | **9/18** | **9/18** |

---

## Root Cause Analysis

Two independent failure modes, both verified by the session logs:

### Failure 1 — `Skill` meta-tool cannot be suppressed by `--allowedTools`

`Skill` is a Claude Code built-in that loads named skills (e.g. `playwright-cli`). It is
**not** listed in the allowedTools filter and fires regardless of the allowlist. Once
`Skill: playwright-cli` executes, it injects the skill definition into context, and the
model proceeds to use `Bash` for all subsequent browser actions via `playwright-cli` commands.

Consequence in MCP runs: A-MCP-1 and A-MCP-2 performed 9 and 13 Bash calls respectively
instead of MCP tool calls. The MCP tool was used only for the final screenshot step.

### Failure 2 — `--allowedTools Bash(playwright-cli:*)` does not exclude MCP tools

The allowlist for CLI runs only restricts Bash to `playwright-cli:*` commands. It does
**not** block `mcp__playwright__*` tools. The model occasionally chose the MCP screenshot
or snapshot tool directly instead of the CLI equivalent, inserting MCP calls into otherwise
CLI-driven runs.

Consequence in CLI runs: All three B-PC runs have 1–5 MCP `browser_take_screenshot` calls.
C-PC-1 has 1 MCP `browser_snapshot` call. A-PC-1 performed full MCP navigation and
interaction before switching to CLI.

### Why `--dangerously-skip-permissions` is not the cause

The `bypassPermissions` mode means tool calls are executed without prompting the user — it
does not expand the tool allowlist. Bypassing permission checks is orthogonal to which tools
are listed in `--allowedTools`. The filter is applied before execution regardless of
permission mode.

---

## Impact on Existing Results

| Metric | Impact |
|--------|--------|
| Token counts (input/output) | **Invalid for A-arm comparison** — different tool families produce different context sizes and response patterns |
| Cost | Directionally valid for B and C arms; unreliable for A arm |
| Turn counts | Partially valid — turn count reflects task complexity but not approach-specific behavior in contaminated runs |
| Task success | Not affected — all SQL injection and XSS tasks completed successfully regardless of which toolset was used |

The B-MCP and C-MCP arms are clean and can be compared against their CLI counterparts once
CLI-arm purity is established.

---

## Required Fixes for a Valid Re-run

### Fix 1 — Disable `Skill` in MCP runs

Add `--disable-slash-commands` (or equivalent flag) to suppress the `Skill` meta-tool
in MCP-arm `claude -p` calls. Alternatively, rename or remove
`.claude/skills/playwright-cli/` before MCP runs and restore it after.

### Fix 2 — Exclude MCP tools from CLI runs

Either:
- Use an **empty `.mcp.json`** (no `mcpServers`) for CLI-arm runs so MCP tools are not
  registered at all, or
- Add `--disallowedTools "mcp__playwright__*"` to CLI-arm calls if the flag is supported.

The simplest approach is to swap `.mcp.json` for CLI runs (write `{"mcpServers": {}}`) and
restore the real config for MCP runs, symmetric to what the demo script already does for
headed/headless switching.

### Fix 3 — Post-run validator

After each run, parse the session `.jsonl` and fail-fast if any disallowed tool appears:

```bash
# Fail if MCP tools appear in a CLI run
if grep -q '"mcp__playwright__' "$session_file" && [[ "$approach" == "playwright-cli" ]]; then
  echo "  ✗ CONTAMINATION: MCP tool found in CLI run $run_id" >&2
  exit 1
fi
# Fail if Bash/Skill appear in an MCP run (excluding Skill on turn 1)
if grep -q '"Bash"' "$session_file" && [[ "$approach" == "playwright-mcp" ]]; then
  echo "  ✗ CONTAMINATION: Bash found in MCP run $run_id" >&2
  exit 1
fi
```

---

## Demo Confirmation

Running `./run_demo.sh` (MCP mode, Task A) on 2026-02-19 produced:

```
[01]   → Skill                           playwright-cli
[03]   → Bash                            playwright-cli open http://localhost:3333
[04]   → Bash                            playwright-cli snapshot
...
[27]   → Read
  Result: SQL Injection Bypass — Successful
  Cost:   $0.4664   Turns:  23   Time:   86.4s
```

Turn 1 was `Skill: playwright-cli`. No MCP tools appeared. The entire run used the CLI
toolchain despite an MCP-only allowlist — confirming that `Skill` bypasses `--allowedTools`.

The SQL injection itself succeeded: the browser logged in as `admin@juice-sh.op` using the
payload `' OR true--` with any password, confirming the task logic is correct.

---

## Recommendation

Discard the current 18-run dataset for any MCP-vs-CLI cost comparison involving Task A.
B and C arms are usable with the caveat that CLI runs have a low-frequency MCP screenshot
leak (1 tool call per run in B-PC, 1 in C-PC-1). Re-run with Fixes 1–3 applied for a
clean dataset.
